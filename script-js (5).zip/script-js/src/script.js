
      import React, { useState } from 'https://esm.sh/react@18.2.0';
import ReactDOM from 'https://esm.sh/react-dom@18.2.0';

function App() {
  const [assignments, setAssignments] = useState([
    { id: 1, title: 'Web Tech Lab 1', subject: 'Web Technology', dueDate: '2026-06-20', status: 'Pending' },
    { id: 2, title: 'Java Strings Project', subject: 'Java Programming', dueDate: '2026-06-12', status: 'Submitted' },
    { id: 3, title: 'Cloud Computing Intro', subject: 'Cloud Technology', dueDate: '2026-06-10', status: 'Late' },
  ]);

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [filterSubject, setFilterSubject] = useState('All');

  const handleAddAssignment = (e) => {
    e.preventDefault();
    if (!title || !subject || !dueDate) {
      alert("Please fill all the fields!");
      return;
    }

    const newAssignment = {
      id: Date.now(),
      title,
      subject,
      dueDate,
      status: 'Pending',
    };

    setAssignments([...assignments, newAssignment]);
    setTitle('');
    setSubject('');
    setDueDate('');
  };

  const handleStatusChange = (id, newStatus) => {
    const updated = assignments.map((asm) => {
      if (asm.id === id) {
        return { ...asm, status: newStatus };
      }
      return asm;
    });
    setAssignments(updated);
  };

  const totalCount = assignments.length;
  const submittedCount = assignments.filter(a => a.status === 'Submitted').length;
  const pendingCount = assignments.filter(a => a.status === 'Pending').length;
  const lateCount = assignments.filter(a => a.status === 'Late').length;

  const uniqueSubjects = ['All', ...new Set(assignments.map(a => a.subject))];
  const filteredAssignments = filterSubject === 'All' 
    ? assignments 
    : assignments.filter(a => a.subject === filterSubject);

  return (
    <div className="container">
      <header>
        <h1>College Assignment Submission Tracker</h1>
        <p className="subtitle">Project-Based React Development & Career Readiness</p>
      </header>

      <div className="dashboard-summary">
        <div className="card total">
          <h3>Total</h3>
          <p>{totalCount}</p>
        </div>
        <div className="card submitted">
          <h3>Submitted</h3>
          <p>{submittedCount}</p>
        </div>
        <div className="card pending">
          <h3>Pending</h3>
          <p>{pendingCount}</p>
        </div>
        <div className="card late">
          <h3>Late</h3>
          <p>{lateCount}</p>
        </div>
      </div>

      <div className="main-content">
        <div className="form-section">
          <h2>Add New Assignment</h2>
          <form onSubmit={handleAddAssignment}>
            <div className="form-group">
              <label>Assignment Title:</label>
              <input 
                type="text" 
                placeholder="e.g., HTML Registration Form" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
              />
            </div>
            <div className="form-group">
              <label>Subject:</label>
              <input 
                type="text" 
                placeholder="e.g., Web Technology" 
                value={subject} 
                onChange={(e) => setSubject(e.target.value)} 
              />
            </div>
            <div className="form-group">
              <label>Due Date:</label>
              <input 
                type="date" 
                value={dueDate} 
                onChange={(e) => setDueDate(e.target.value)} 
              />
            </div>
            <button type="submit" className="btn-submit">Add Assignment</button>
          </form>
        </div>

        <div className="list-section">
          <div className="list-header">
            <h2>Assignment Status</h2>
            <div className="filter-group">
              <label>Filter by Subject: </label>
              <select value={filterSubject} onChange={(e) => setFilterSubject(e.target.value)}>
                {uniqueSubjects.map((sub, index) => (
                  <option key={index} value={sub}>{sub}</option>
                ))}
              </select>
            </div>
          </div>

          <table className="assignment-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Subject</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredAssignments.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: 'center' }}>No assignments found!</td>
                </tr>
              ) : (
                filteredAssignments.map((asm) => (
                  <tr key={asm.id}>
                    <td><strong>{asm.title}</strong></td>
                    <td><span className="subject-tag">{asm.subject}</span></td>
                    <td>{asm.dueDate}</td>
                    <td>
                      <span className={`status-badge ${asm.status.toLowerCase()}`}>
                        {asm.status}
                      </span>
                    </td>
                    <td>
                      <select 
                        value={asm.status} 
                        onChange={(e) => handleStatusChange(asm.id, e.target.value)}
                        className="status-selector"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Submitted">Submitted</option>
                        <option value="Late">Late</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);     
            