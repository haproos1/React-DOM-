# Script.js

A Pen created on CodePen.

Original URL: [https://codepen.io/Haproos-Fathima-Haproos-Fathima/pen/YPNpGjx](https://codepen.io/Haproos-Fathima-Haproos-Fathima/pen/YPNpGjx).

